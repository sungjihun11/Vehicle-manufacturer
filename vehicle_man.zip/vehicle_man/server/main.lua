ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local NumberCharset = {}
local Charset = {}

for i = 48,  57 do table.insert(NumberCharset, string.char(i)) end

for i = 65,  90 do table.insert(Charset, string.char(i)) end
for i = 97, 122 do table.insert(Charset, string.char(i)) end

function GetRandomLetter(length)
	if length > 0 then
		return GetRandomLetter(length - 1) .. Charset[math.random(1, #Charset)]
	else
		return ''
	end
end

function GetRandomNumber(length)
	if length > 0 then
		return GetRandomNumber(length - 1) .. NumberCharset[math.random(1, #NumberCharset)]
	else
		return ''
	end
end

function GeneratePlate()
	local generatedPlate
	local doBreak = false
	generatedPlate = string.upper(GetRandomLetter(3) ..' '.. GetRandomNumber(3))
	return generatedPlate
end

RegisterServerEvent('Manufacture:jobcheck')
AddEventHandler('Manufacture:jobcheck', function()
	
	local src = source
	local player = ESX.GetPlayerFromId(src)
	if jobRequired then
		if player.job.name == jobName then
			TriggerClientEvent('ui:respond', src, true)
			local plate = GeneratePlate()
			TriggerClientEvent('NumberPlateStr',src, plate)
		else
			TriggerClientEvent('notification', src, string.format(notInJob, jobName))
		end
	else
		TriggerClientEvent('ui:respond', src, true)
	end

end)

RegisterServerEvent('changeOwner')
AddEventHandler('changeOwner', function(plate, targetPlayer, veh)
	_source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local target = ESX.GetPlayerFromId(targetPlayer)
	if jobRequired then
		if xPlayer.job.name == jobName then
			MySQL.scalar('SELECT plate FROM owned_vehicles WHERE plate = ?', {plate},
			function(result)
				if result == nil then
					MySQL.insert('INSERT INTO owned_vehicles (owner, plate, vehicle) VALUES (?, ?, ?)', {target.identifier, plate, json.encode(veh)})
					TriggerClientEvent('notification', _source, string.format('You give vehicle with plate ~y~%s ~w~to ~g~%s', plate, target.name))
				else
					TriggerClientEvent('notification', _source, '~r~This number plate already taken')
				end
			end)
		else
			TriggerClientEvent('notification', _source, string.format('Your are not in ~g~%s ~w~job', jobName))
		end
	end
end)