var createElement = false

function display(bool) {
    if (bool) {
        document.getElementById("container").style.display = "block";;
    } else {
        document.getElementById("container").style.display = "none";;
    }
}

function changeBackground(url) {
    document.getElementById('panel').style.backgroundImage = "url(" + url + ")";
}

display(false)

window.addEventListener('message', function(event) {
    var nui = event.data;
    if (nui.type === "ui") {
        if (createElement === false){        
            nui.hash.forEach(element => {
                document.getElementById("lists").innerHTML += "<li id="+element+">" +nui.label[element] +"</li>"
            });
            createElement = true
        }
        if (nui.img !== null) {
            changeBackground(nui.img)
        }
        if (nui.status == true) {
            display(true)
        } else {
            display(false)
        }
    }
})

document.getElementById('lists').addEventListener('click', function(e){
    fetch(`https://${GetParentResourceName()}/spawnshell`, {
        method: 'POST',
        headers: {
            'Content-Type' : 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({
            vehicle: e.target.id,
        })
    })
    display(false)
})

document.getElementById('cancel').addEventListener('click', function(event){
    fetch(`https://${GetParentResourceName()}/closeui`, {})
})