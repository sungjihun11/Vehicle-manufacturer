jobRequired = true
jobName = 'taxi'

menuHelp = 'Press ~INPUT_PICKUP~ to open blueprint list menu'
notInJob = 'Your not in %s job'
shellalreadySpawned = 'Already you working with some model'
helpSetShellPos = "~INPUT_REPLAY_BACK~/~INPUT_REPLAY_ADVANCE~ ~g~X-axis~w~~n~~INPUT_REPLAY_FFWD~/~INPUT_REPLAY_REWIND~ ~g~Y-axis~w~~n~~INPUT_PICKUP~ ~g~confirm"
objectError = 'Already you have one parts in your hand'

menuPanelBackgroundImgUrl = './image/logo.jpg'

buildCarModelLabels = {
    ['adder'] = "ADDER",
    ['ninef2'] = "DOUBLE",
    ['baller2'] = "BALLER2",
    ['buzzard'] = "BUZZARD",
    ['hunter'] = 'HUNTER',
    ['taco'] = 'TRUCK',
    ['phantom'] = 'TRUCK2'
}

buildCarModel = {
    "adder",
    "ninef2",
    "baller2",
    "buzzard",
    "hunter",
    "taco",
    "phantom",
}

bluePrintCoord = {
    bluePrintPos = {id = 1, x = 1049.367, y = 3083.393, z = 41.59705},
    doorCoords = {id = 2, x = 1059.099, y = 3086.253, z = 41.3949, r = 0, g = 255, b = 0, help = 'Press ~INPUT_PICKUP~ to take door'},
    breakCoord = {id = 3, x = 1063.099, y = 3087.745, z = 41.1084, r = 0, g = 255, b = 0, help = 'Press ~INPUT_PICKUP~ to take break'},
    wheelCoords = {id = 4, x = 1068.185, y = 3088.998, z = 40.90625, r = 0, g = 255, b = 0, help = 'Press ~INPUT_PICKUP~ to take wheel'},
    seatCoords = {id = 5, x = 1055.393, y = 3085.253, z = 41.3949, r = 0, g = 255, b = 0, help = 'Press ~INPUT_PICKUP~ to take seat'},
    trunkCoords = {id = 6, x = 1071.917, y = 3090.013, z = 40.75464, r = 0, g = 255, b = 0, help = 'Press ~INPUT_PICKUP~ to take trunk'},
    bonnetCoords = {id = 7, x = 1084.378, y = 3093.719, z = 40.45129, r = 0, g = 255, b = 0, help = 'Press ~INPUT_PICKUP~ to take boonet'},
    engineCoords = {id = 8, x = 1080.765, y = 3092.453, z = 40.43445, r = 0, g = 255, b = 0, help = 'Press ~INPUT_PICKUP~ to take engine'},
    transmissionCoords = {id = 9, x = 1076.505, y = 3091.16, z = 40.55237, r = 0, g = 255, b = 0, help = 'Press ~INPUT_PICKUP~ to take transmission'},
    exahustCoords = {id = 10, x = 1087.965, y = 3094.747, z = 40.45129, r = 0, g = 255, b = 0, help = 'Press ~INPUT_PICKUP~ to take exahust'},
    analysisVehi = {id = 11, x = 1043.802, y = 3085.556, z = 41.76562, r = 0, g = 255, b = 0, help = 'Press ~INPUT_PICKUP~ to analysis vehicle'},
    scale = 1.0,
    rbga = {r = 0, g = 0, b = 255, a = 255},
}

shellSpawnCoord = {x = 1049.815, y = 3076.246, z = 41.63074, heading = 195.5905}

trailerCoord = {
    x = 1077.363, y = 3058.84, z = 40.9231, heading = 286.2992
}
truckCoord = {
    x = 1085.235, y = 3067.029, z = 40.60291, heading = 11.33858
}