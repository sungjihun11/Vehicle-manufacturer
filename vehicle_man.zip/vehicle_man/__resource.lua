fx_version 'cerulean'
games {'gta5' }

client_scripts {
    "config.lua",
    "/client/main.lua",
} 

server_scripts {
    "config.lua",
    "/server/main.lua",
    "@oxmysql/lib/MySQL.lua",
}

ui_page 'nui/index.html'

files {
    'nui/index.html',
    'nui/style.css',
    'nui/script.js',
    'nui/image/*',
}