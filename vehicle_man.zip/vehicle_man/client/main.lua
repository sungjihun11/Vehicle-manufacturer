ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local displayMenu = false
local trailer = nil
local modelShell = nil
local doorCount = 0
local wheelCount = 0
local numberPlate = nil
local seatIndex = {}
local seatState = {}
seatIndex['seat_dside_f'] = -1
seatIndex['seat_dside_r'] = 1
seatIndex['seat_pside_f'] = 0
seatIndex['seat_pside_r'] = 2
seatState['-1'] = false
seatState['1'] = false
seatState['0'] = false
seatState['2'] = false
local doorState = {}
local doorIndex = {}
doorState['seat_dside_f'] = false
doorState['seat_dside_r'] = false
doorState['seat_pside_f'] = false
doorState['seat_pside_r'] = false
doorState['bonnet'] = false
doorState['trunk'] = false
doorIndex['seat_dside_f'] = 0
doorIndex['seat_dside_r'] = 2
doorIndex['seat_pside_f'] = 1
doorIndex['seat_pside_r'] = 3
doorIndex['bonnet'] = 4
doorIndex['trunk'] = 5
local wheelState = {}
local wheelIndex = {}
wheelState['0'] = false
wheelState['1'] = false
wheelState['2'] = false
wheelState['3'] = false
wheelState['4'] = true
wheelState['5'] = true
wheelIndex['wheel_lf'] = 0
wheelIndex['wheel_rf'] = 1
wheelIndex['wheel_lm'] = 4
wheelIndex['wheel_rm'] = 5
wheelIndex['wheel_lr'] = 2
wheelIndex['wheel_rr'] = 3
local berakState = {}
local berakIndex = {}
berakState['0'] = false
berakState['1'] = false
berakState['2'] = false
berakState['3'] = false
berakState['4'] = true
berakState['5'] = true
berakIndex['wheel_lf'] = 0
berakIndex['wheel_rf'] = 1
berakIndex['wheel_lm'] = 4
berakIndex['wheel_rm'] = 5
berakIndex['wheel_lr'] = 2
berakIndex['wheel_rr'] = 3
exhaust = false
engine = false
transmission = false
local locationFixed = false
local fullFixed = false
local currentObject = nil
local objectSpawned = false

function Help(msg)
    SetTextComponentFormat("STRING")
    AddTextComponentString(msg)
    DisplayHelpTextFromStringLabel(0,0,0,-1)
end

function AnimationLoad(animdict)
    RequestAnimDict(animdict)
    while not HasAnimDictLoaded(animdict) do
        Citizen.Wait(0)
    end
end

function DrawText3D(pos, text)
	local onScreen,_x,_y=World3dToScreen2d(pos.x,pos.y,pos.z)

	if onScreen then
		SetTextScale(0.55, 0.55)
		SetTextFont(4)
		SetTextProportional(1)
		SetTextColour(255, 255, 255, 215)
		SetTextEntry("STRING")
		SetTextCentre(1)
		AddTextComponentString(text)
		DrawText(_x,_y)
	end
end


function SpawnSeat()
    local ped = GetPlayerPed(-1)
    local coords = GetEntityCoords(ped)
    AnimationLoad("anim@heists@box_carry@")
    TaskPlayAnim(ped, "anim@heists@box_carry@", "idle", 5.0, -1, -1, 50, 0, false, false, false)
    currentObject = CreateObject(GetHashKey('prop_car_seat'), coords.x, coords.y, coords.z, true, true, true)
    AttachEntityToEntity(currentObject, ped, GetPedBoneIndex(ped, 56604), 0.1, 0.40, -0.65, 0.0, 0.0, 180.0, true, true, false, true, 1, true)
end

function SpawnDoor()
    local ped = GetPlayerPed(-1)
    local coords = GetEntityCoords(ped)
    AnimationLoad("anim@heists@box_carry@")
    TaskPlayAnim(ped, "anim@heists@box_carry@", "idle", 5.0, -1, -1, 50, 0, false, false, false)
    currentObject = CreateObject(GetHashKey('prop_car_door_01'), coords.x, coords.y, coords.z, true, true, true)
    AttachEntityToEntity(currentObject, ped, GetPedBoneIndex(ped, 56604), 0.1, 0.40, -0.65, 0.0, 0.0, 180.0, true, true, false, true, 1, true)
end

function SpawnBonnet()
    local ped = GetPlayerPed(-1)
    local coords = GetEntityCoords(ped)
    AnimationLoad("anim@heists@box_carry@")
    TaskPlayAnim(ped, "anim@heists@box_carry@", "idle", 5.0, -1, -1, 50, 0, false, false, false)
    currentObject = CreateObject(GetHashKey('imp_prop_impexp_bonnet_02a'), coords.x, coords.y, coords.z, true, true, true)
    AttachEntityToEntity(currentObject, ped, GetPedBoneIndex(ped, 56604), 0.0, 0.75, 0.45, 2.0, 0.0, 0.0, true, true, false, true, 1, true)
end

function SpawnTrunk()
    local ped = GetPlayerPed(-1)
    local coords = GetEntityCoords(ped)
    AnimationLoad("anim@heists@box_carry@")
    TaskPlayAnim(ped, "anim@heists@box_carry@", "idle", 5.0, -1, -1, 50, 0, false, false, false)
    currentObject = CreateObject(GetHashKey('imp_prop_impexp_trunk_01a'), coords.x, coords.y, coords.z, true, true, true)
    AttachEntityToEntity(currentObject, ped, GetPedBoneIndex(ped, 56604), 0.0, 0.40, 0.1, 0.0, 0.0, 180.0, true, true, false, true, 1, true)
end

function SpawnWheel()
    local ped = GetPlayerPed(-1)
    local coords = GetEntityCoords(ped)
    AnimationLoad("anim@heists@box_carry@")
    TaskPlayAnim(ped, "anim@heists@box_carry@", "idle", 5.0, -1, -1, 50, 0, false, false, false)
    currentObject = CreateObject(GetHashKey('prop_wheel_01'), coords.x, coords.y, coords.z, true, true, true)
    AttachEntityToEntity(currentObject, ped, GetPedBoneIndex(ped, 56604), -0.08, 0.30, 0.37, 0.0, 0.0, 180.0, true, true, false, true, 1, true)
end

function SpawnEngine()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    AnimationLoad("anim@heists@box_carry@")
    TaskPlayAnim(ped, "anim@heists@box_carry@" ,"idle", 5.0, -1, -1, 50, 0, false, false, false)
    currentObject = CreateObject(GetHashKey('prop_car_engine_01'), coords.x, coords.y, coords.z,  true,  true, true)
	AttachEntityToEntity(currentObject, ped, GetPedBoneIndex(ped, 56604), 0.025, 0.0, 0.15, 90.0, 0.0, 180.0, true, true, false, true, 1, true)
end

function SpawnTransmission()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    AnimationLoad("anim@heists@box_carry@")
    TaskPlayAnim(ped, "anim@heists@box_carry@" ,"idle", 5.0, -1, -1, 50, 0, false, false, false)
    currentObject = CreateObject(GetHashKey('imp_prop_impexp_gearbox_01'), coords.x, coords.y, coords.z,  true,  true, true)
    AttachEntityToEntity(currentObject, ped, GetPedBoneIndex(ped, 56604), -0.08, 0.30, 0.37, 0.0, 0.0, 180.0, true, true, false, true, 1, true)
end

function SpawnExhaust()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
	AnimationLoad("anim@heists@box_carry@")
    TaskPlayAnim(ped, "anim@heists@box_carry@" ,"idle", 5.0, -1, -1, 50, 0, false, false, false)
    currentObject = CreateObject(GetHashKey('imp_prop_impexp_exhaust_01'), coords.x, coords.y, coords.z,  true,  true, true)
    AttachEntityToEntity(currentObject, ped, GetPedBoneIndex(ped, 56604), -0.08, 0.30, 0.37, 0.0, 0.0, 180.0, true, true, false, true, 1, true)
end

function SpawnBrake()
    local ped = GetPlayerPed(-1)
    local coords = GetEntityCoords(ped)
	AnimationLoad("anim@heists@box_carry@")
    TaskPlayAnim(ped, "anim@heists@box_carry@" ,"idle", 5.0, -1, -1, 50, 0, false, false, false)
    currentObject = CreateObject(GetHashKey('imp_prop_impexp_brake_caliper_01a'), coords.x, coords.y, coords.z,  true,  true, true)
    AttachEntityToEntity(currentObject, ped, GetPedBoneIndex(ped, 56604), -0.08, 0.30, 0.37, 0.0, 0.0, 180.0, true, true, false, true, 1, true)
end

function UpdateShell()
    SetVehicleFixed(modelShell)
    for k,v in pairs(wheelIndex) do
        if wheelState[tostring(v)] == false then
            SetVehicleWheelTireColliderSize(modelShell, v, -5.0)
        elseif wheelState[tostring(v)] == true then
            SetVehicleWheelTireColliderSize(modelShell, v, 0.4)
        end
    end
    for k,v in pairs(doorState) do
        if not doorState[k] then
            SetVehicleDoorBroken(modelShell, doorIndex[k], true)
        end
    end
end

function InstallDoor()
    local installing = true
    local shellCoords = GetEntityCoords(modelShell)
    local doors = {
        'seat_dside_f',
        'seat_dside_r',
        'seat_pside_f',
        'seat_pside_r'
    }
    while installing and currentObject ~= nil do
        local pedPos = GetEntityCoords(GetPlayerPed(-1))
        if #(shellCoords - pedPos) < 10 then
            for k, v in pairs(doors) do
                local bone = GetEntityBoneIndexByName(modelShell, v)
                local coordbone = GetWorldPositionOfEntityBone(modelShell, bone)
                if bone ~= -1 and doorState[v] == false then
                    if #(GetEntityCoords(GetPlayerPed(-1)) - coordbone) < 1.01 then
                        DrawText3D(coordbone, '[~b~E~w~] - To Attach')
                        if IsControlJustPressed(0, 38) and seatState[tostring(seatIndex[v])] == true then
                            doorState[v] = true
                            SetEntityAlpha(modelShell, 255, true)
                            DeleteObject(currentObject)
                            ClearPedTasks(GetPlayerPed(-1))
                            installing = false
                            currentObject = nil
                            UpdateShell()
                        end
                    end
                end
            end
            
            if IsControlJustPressed(0, 73) then
                DeleteObject(currentObject)
                ClearPedTasks(GetPlayerPed(-1))
                installing = false
                currentObject = nil
            end
        end
        Citizen.Wait(0)
    end
end

function InstallSeat()
    local installing = true
    local shellCoords = GetEntityCoords(modelShell)
    local seat = {
        'seat_dside_f',
        'seat_dside_r',
        'seat_pside_f',
        'seat_pside_r'
    }
    while installing and currentObject ~= nil do
        local pedPos = GetEntityCoords(GetPlayerPed(-1))
        if #(shellCoords - pedPos) < 10 then
            for k, v in pairs(seat) do
                local bone = GetEntityBoneIndexByName(modelShell, v)
                local coordbone = GetWorldPositionOfEntityBone(modelShell, bone)
                if bone ~= -1 and seatState[tostring(seatIndex[v])] == false then
                    if #(GetEntityCoords(GetPlayerPed(-1)) - coordbone) <= 1.01 then
                        DrawText3D(coordbone, '[~b~E~w~] - To Attach')
                        if IsControlJustPressed(0, 38) then
                            seatState[tostring(seatIndex[v])] = true
                            SetEntityAlpha(modelShell, 255, true)
                            DeleteObject(currentObject)
                            ClearPedTasks(GetPlayerPed(-1))
                            installing = false
                            currentObject = nil
                            UpdateShell()
                        end
                    end
                end
            end
            
            if IsControlJustPressed(0, 73) then
                DeleteObject(currentObject)
                ClearPedTasks(GetPlayerPed(-1))
                installing = false
                currentObject = nil
            end
        end
        Citizen.Wait(0)
    end
end

function InstallWheel()
    local installing = true
    local shellCoords = GetEntityCoords(modelShell)
    local wheels = {
        'wheel_lf',
        'wheel_rf',
        'wheel_lm',
        'wheel_rm',
        'wheel_lr',
        'wheel_rr',
    }
    while installing and currentObject ~= nil do
        local pedPos = GetEntityCoords(GetPlayerPed(-1))
        if #(shellCoords - pedPos) < 10 then
            for k, v in pairs(wheels) do
                local bone = GetEntityBoneIndexByName(modelShell, v)
                local coordbone = GetWorldPositionOfEntityBone(modelShell, bone) + vector3(0.0,0.0,5.0)
                if bone ~= -1 and wheelState[tostring(wheelIndex[v])] == false then
                    if #(GetEntityCoords(GetPlayerPed(-1)) - coordbone) < 2 then
                        DrawText3D(coordbone, '[~b~E~w~] - To Attach')
                        if IsControlJustPressed(0, 38) and berakState[tostring(berakIndex[v])] == true then
                            wheelState[tostring(wheelIndex[v])] = true
                            SetEntityAlpha(modelShell, 255, true)
                            DeleteObject(currentObject)
                            ClearPedTasks(GetPlayerPed(-1))
                            installing = false
                            currentObject = nil
                            UpdateShell()
                        end
                    end
                end
            end
            
            if IsControlJustPressed(0, 73) then
                DeleteObject(currentObject)
                ClearPedTasks(GetPlayerPed(-1))
                installing = false
                currentObject = nil
            end
        end
        Citizen.Wait(0)
    end
end

function InstallBreak()
    local installing = true
    local shellCoords = GetEntityCoords(modelShell)
    local breaks = {
        'wheel_lf',
        'wheel_rf',
        'wheel_lm',
        'wheel_rm',
        'wheel_lr',
        'wheel_rr',
    }
    while installing and currentObject ~= nil do
        local pedPos = GetEntityCoords(GetPlayerPed(-1))
        if #(shellCoords - pedPos) < 10 then
            for k, v in pairs(breaks) do
                local bone = GetEntityBoneIndexByName(modelShell, v)
                local coordbone = GetWorldPositionOfEntityBone(modelShell, bone) + vector3(0.0,0.0,5.0)
                if bone ~= -1 and berakState[tostring(berakIndex[v])] == false then
                    if #(GetEntityCoords(GetPlayerPed(-1)) - coordbone) < 2 then
                        DrawText3D(coordbone, '[~b~E~w~] - To Attach')
                        if IsControlJustPressed(0, 38) then
                            berakState[tostring(berakIndex[v])] = true
                            SetEntityAlpha(modelShell, 255, true)
                            DeleteObject(currentObject)
                            ClearPedTasks(GetPlayerPed(-1))
                            installing = false
                            currentObject = nil
                            UpdateShell()
                        end
                    end
                end
            end
            
            if IsControlJustPressed(0, 73) then
                DeleteObject(currentObject)
                ClearPedTasks(GetPlayerPed(-1))
                installing = false
                currentObject = nil
            end
        end
        Citizen.Wait(0)
    end
end

function InstallTrunk()
    local installing = true
    local shellCoords = GetEntityCoords(modelShell)
    while installing and currentObject ~= nil do
        local pedPos = GetEntityCoords(GetPlayerPed(-1))
        if #(shellCoords - pedPos) < 10 then
            local bone = GetEntityBoneIndexByName(modelShell, 'boot')
            local coordbone = GetWorldPositionOfEntityBone(modelShell, bone)
            if bone ~= -1 and doorState['trunk'] == false then
                if #(GetEntityCoords(GetPlayerPed(-1)) - coordbone) < 5 then
                    DrawText3D(coordbone, '[~b~E~w~] - To Attach')
                    if IsControlJustPressed(0, 38) then
                        doorState['trunk'] = true
                        DeleteObject(currentObject)
                        ClearPedTasks(GetPlayerPed(-1))
                        installing = false
                        currentObject = nil
                        UpdateShell()
                    end
                end
            end
            if IsControlJustPressed(0, 73) then
                DeleteObject(currentObject)
                ClearPedTasks(GetPlayerPed(-1))
                installing = false
                currentObject = nil
            end
        end
        Citizen.Wait(0)
    end
end

function InstallBonnet()
    local installing = true
    local shellCoords = GetEntityCoords(modelShell)
    while installing and currentObject ~= nil do
        local pedPos = GetEntityCoords(GetPlayerPed(-1))
        if #(shellCoords - pedPos) < 10 then
            local bone = GetEntityBoneIndexByName(modelShell, 'bonnet')
            local coordbone = GetWorldPositionOfEntityBone(modelShell, bone)
            if bone ~= -1 and doorState['bonnet'] == false then
                if #(GetEntityCoords(GetPlayerPed(-1)) - coordbone) < 5 then
                    DrawText3D(coordbone, '[~b~E~w~] - To Attach')
                    if IsControlJustPressed(0, 38) then
                        doorState['bonnet'] = true
                        DeleteObject(currentObject)
                        ClearPedTasks(GetPlayerPed(-1))
                        installing = false
                        currentObject = nil
                        UpdateShell()
                    end
                end
            end
            if IsControlJustPressed(0, 73) then
                DeleteObject(currentObject)
                ClearPedTasks(GetPlayerPed(-1))
                installing = false
                currentObject = nil
            end
        end
        Citizen.Wait(0)
    end
end

function InstallExhaust()
    local installing = true
    local shellCoords = GetEntityCoords(modelShell)
    while installing and currentObject ~= nil do
        local pedPos = GetEntityCoords(GetPlayerPed(-1))
        if #(shellCoords - pedPos) < 10 then
            local bone = GetEntityBoneIndexByName(modelShell, 'exhaust')
            local coordbone = GetWorldPositionOfEntityBone(modelShell, bone)
            if bone ~= -1 and exhaust == false then
                if #(GetEntityCoords(GetPlayerPed(-1)) - coordbone) < 5 then
                    DrawText3D(coordbone, '[~b~E~w~] - To Attach')
                    if IsControlJustPressed(0, 38) then
                        exhaust = true
                        DeleteObject(currentObject)
                        ClearPedTasks(GetPlayerPed(-1))
                        installing = false
                        currentObject = nil
                    end
                end
            end
            if IsControlJustPressed(0, 73) then
                DeleteObject(currentObject)
                ClearPedTasks(GetPlayerPed(-1))
                installing = false
                currentObject = nil
            end
        end
        Citizen.Wait(0)
    end
end

function InstallEngine()
    local installing = true
    local shellCoords = GetEntityCoords(modelShell)
    while installing and currentObject ~= nil do
        local pedPos = GetEntityCoords(GetPlayerPed(-1))
        if #(shellCoords - pedPos) < 10 then
            local bone = GetEntityBoneIndexByName(modelShell, 'engine')
            local coordbone = GetWorldPositionOfEntityBone(modelShell, bone)
            if bone ~= -1 and engine == false then
                if #(GetEntityCoords(GetPlayerPed(-1)) - coordbone) < 5 then
                    DrawText3D(coordbone, '[~b~E~w~] - To Attach')
                    if IsControlJustPressed(0, 38) then
                        engine = true
                        DeleteObject(currentObject)
                        ClearPedTasks(GetPlayerPed(-1))
                        installing = false
                        currentObject = nil
                    end
                end
            end
            if IsControlJustPressed(0, 73) then
                DeleteObject(currentObject)
                ClearPedTasks(GetPlayerPed(-1))
                installing = false
                currentObject = nil
            end
        end
        Citizen.Wait(0)
    end
end

function InstallTransmission()
    local installing = true
    local shellCoords = GetEntityCoords(modelShell)
    while installing and currentObject ~= nil do
        local pedPos = GetEntityCoords(GetPlayerPed(-1))
        if #(shellCoords - pedPos) < 10 then
            local bone = GetEntityBoneIndexByName(modelShell, 'engine')
            local coordbone = GetWorldPositionOfEntityBone(modelShell, bone)
            if bone ~= -1 and transmission == false then
                if #(GetEntityCoords(GetPlayerPed(-1)) - coordbone) < 5 then
                    DrawText3D(coordbone, '[~b~E~w~] - To Attach')
                    if IsControlJustPressed(0, 38) then
                        transmission = true
                        DeleteObject(currentObject)
                        ClearPedTasks(GetPlayerPed(-1))
                        installing = false
                        currentObject = nil
                    end
                end
            end
            if IsControlJustPressed(0, 73) then
                DeleteObject(currentObject)
                ClearPedTasks(GetPlayerPed(-1))
                installing = false
                currentObject = nil
            end
        end
        Citizen.Wait(0)
    end
end

function AnalysisVeh()
    local Abreak = true
    local Awheel = true
    local Aseat = true
    local Adoor = true
    local Aexhaust = true
    local Aengine = true
    local Atran = true
    local msg = '~r~Missing Parts:~w~~n~'
    while true do
        Citizen.Wait(0)
        for k,v in pairs(berakState) do
            if v == false then
                msg = msg..'break~n~'
                Abreak = false
                break
            end
        end
        for k,v in pairs(wheelState) do
            if v == false then
                Awheel = false
                msg = msg..'wheel~n~'
                break
            end
        end
        for k,v in pairs(seatState) do
            if v == false then
                Aseat = false
                msg = msg..'seat~n~'
                break
            end
        end
        for k,v in pairs(doorState) do
            if v == false and k ~= 'trunk' then
                Adoor = false
                msg = msg..'door~n~'
                break
            end
        end
        if exhaust == false then
            Aexhaust = false
            msg = msg..'exhaust~n~'
        end
        if engine == false then
            Aengine = false
            msg = msg..'engine~n~'
        end
        if transmission == false then
            Atran = false
            msg = msg..'transmission~n~'
        end
        if Abreak and Awheel and Aseat and Adoor and Aexhaust and Aengine and Atran then
            FreezeEntityPosition(modelShell, false)
            SetVehicleUndriveable(modelShell, false)
            fullFixed = true
            modelShell = nil
            break
        else
            TriggerEvent('notification', msg)
            break
        end
    end
end

function SetDisplay(bool)
    displayMenu = bool
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        type = "ui",
        status = bool,
        label = buildCarModelLabels,
        hash = buildCarModel,
        img = menuPanelBackgroundImgUrl
    })
end

RegisterNetEvent('ui:respond')
AddEventHandler('ui:respond', function(bool)
    SetDisplay(bool)
end)

RegisterNetEvent('notification')
AddEventHandler('notification', function(msg)

    BeginTextCommandThefeedPost("STRING")
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)

end)

RegisterNUICallback('spawnshell', function(data, cb)
    cb({})
    SetDisplay(false)
    RequestModel(GetHashKey(data.vehicle))
    while not HasModelLoaded(GetHashKey(data.vehicle)) do
        Wait(0)
    end    
    if modelShell == nil then
        modelShell = CreateVehicle(GetHashKey(data.vehicle), shellSpawnCoord.x + 2.0, shellSpawnCoord.y, shellSpawnCoord.z, shellSpawnCoord.heading, false, true)
        wheelCount = GetVehicleNumberOfWheels(modelShell)
        doorCount = GetNumberOfVehicleDoors(modelShell)
        for i = 0, wheelCount, 1 do
            SetVehicleWheelTireColliderSize(modelShell, i, -5.0)
        end

        for i = 0, doorCount,1 do
            SetVehicleDoorBroken(modelShell, i, true)
        end
        SetVehicleDoorBroken(modelShell, 4, true)
        SetVehicleDoorBroken(modelShell, 5, true)
        FreezeEntityPosition(modelShell, true)
        SetEntityAlpha(modelShell, 155, true)
        if numberPlate ~= nil then
            SetVehicleNumberPlateText(modelShell, numberPlate)
        end
        SetVehicleUndriveable(modelShell, true)
        TriggerEvent('shell:setpos')
        fullFixed = false
    else
        TriggerEvent('notification', shellalreadySpawned)
    end
end)

RegisterNUICallback('closeui', function(data, cb)
    cb({})
    SetDisplay(false)
end)

RegisterNetEvent('shell:setpos')
AddEventHandler('shell:setpos', function()

    while true do
        Wait(0)
        Help(helpSetShellPos)
        if IsControlJustPressed(0, 38) then
            TriggerEvent('shell:startfix')
            SetEntityAlpha(modelShell, 255, true)
            break
        end
        if IsControlPressed(0, 307) then
            SetEntityCoords(modelShell, GetOffsetFromEntityInWorldCoords(modelShell, 0.01, 0.0, 0.0))
        end
        if IsControlPressed(0, 308) then
            SetEntityCoords(modelShell, GetOffsetFromEntityInWorldCoords(modelShell, -0.01, 0.0, 0.0))
        end
        if IsControlPressed(0, 300) then
            SetEntityCoords(modelShell, GetOffsetFromEntityInWorldCoords(modelShell, 0.0, 0.01, 0.0))
        end
        if IsControlPressed(0, 299) then
            SetEntityCoords(modelShell, GetOffsetFromEntityInWorldCoords(modelShell, 0.0, -0.01, 0.0))
        end
    end

end)

RegisterNetEvent('shell:startfix')
AddEventHandler('shell:startfix', function()

    while fullFixed == false do
        Wait(0)
        DrawMarker(bluePrintCoord.doorCoords.id, bluePrintCoord.doorCoords.x, bluePrintCoord.doorCoords.y, bluePrintCoord.doorCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, bluePrintCoord.scale,bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.doorCoords.r, bluePrintCoord.doorCoords.g, bluePrintCoord.doorCoords.b, 255, false, false, 2, nil, nil, false)
        DrawMarker(bluePrintCoord.breakCoord.id, bluePrintCoord.breakCoord.x, bluePrintCoord.breakCoord.y, bluePrintCoord.breakCoord.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, bluePrintCoord.scale,bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.breakCoord.r, bluePrintCoord.breakCoord.g, bluePrintCoord.breakCoord.b, 255, false, false, 2, nil, nil, false)
        DrawMarker(bluePrintCoord.wheelCoords.id, bluePrintCoord.wheelCoords.x, bluePrintCoord.wheelCoords.y, bluePrintCoord.wheelCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, bluePrintCoord.scale,bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.wheelCoords.r, bluePrintCoord.wheelCoords.g, bluePrintCoord.wheelCoords.b, 255, false, false, 2, nil, nil, false)
        DrawMarker(bluePrintCoord.seatCoords.id, bluePrintCoord.seatCoords.x, bluePrintCoord.seatCoords.y, bluePrintCoord.seatCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, bluePrintCoord.scale,bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.seatCoords.r, bluePrintCoord.seatCoords.g, bluePrintCoord.seatCoords.b, 255, false, false, 2, nil, nil, false)
        DrawMarker(bluePrintCoord.trunkCoords.id, bluePrintCoord.trunkCoords.x, bluePrintCoord.trunkCoords.y, bluePrintCoord.trunkCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, bluePrintCoord.scale,bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.trunkCoords.r, bluePrintCoord.trunkCoords.g, bluePrintCoord.trunkCoords.b, 255, false, false, 2, nil, nil, false)
        DrawMarker(bluePrintCoord.bonnetCoords.id, bluePrintCoord.bonnetCoords.x, bluePrintCoord.bonnetCoords.y, bluePrintCoord.bonnetCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, bluePrintCoord.scale,bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.bonnetCoords.r, bluePrintCoord.bonnetCoords.g, bluePrintCoord.bonnetCoords.b, 255, false, false, 2, nil, nil, false)
        DrawMarker(bluePrintCoord.engineCoords.id, bluePrintCoord.engineCoords.x, bluePrintCoord.engineCoords.y, bluePrintCoord.engineCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, bluePrintCoord.scale,bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.engineCoords.r, bluePrintCoord.engineCoords.g, bluePrintCoord.engineCoords.b, 255, false, false, 2, nil, nil, false)
        DrawMarker(bluePrintCoord.transmissionCoords.id, bluePrintCoord.transmissionCoords.x, bluePrintCoord.transmissionCoords.y, bluePrintCoord.transmissionCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, bluePrintCoord.scale,bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.transmissionCoords.r, bluePrintCoord.transmissionCoords.g, bluePrintCoord.transmissionCoords.b, 255, false, false, 2, nil, nil, false)
        DrawMarker(bluePrintCoord.exahustCoords.id, bluePrintCoord.exahustCoords.x, bluePrintCoord.exahustCoords.y, bluePrintCoord.exahustCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, bluePrintCoord.scale,bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.exahustCoords.r, bluePrintCoord.exahustCoords.g, bluePrintCoord.exahustCoords.b, 255, false, false, 2, nil, nil, false)
        DrawMarker(bluePrintCoord.analysisVehi.id, bluePrintCoord.analysisVehi.x, bluePrintCoord.analysisVehi.y, bluePrintCoord.analysisVehi.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, bluePrintCoord.scale,bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.analysisVehi.r, bluePrintCoord.analysisVehi.g, bluePrintCoord.analysisVehi.b, 255, false, false, 2, nil, nil, false)
        local pedCoord = GetEntityCoords(GetPlayerPed(-1))
        if Vdist(pedCoord, bluePrintCoord.doorCoords.x, bluePrintCoord.doorCoords.y, bluePrintCoord.doorCoords.z) <= bluePrintCoord.scale then
            Help(bluePrintCoord.doorCoords.help)
            if IsControlJustPressed(0, 38) then
                if currentObject == nil then
                    SpawnDoor()
                    InstallDoor()
                else
                    TriggerEvent('notification', objectError)
                end
            end
        end
        if Vdist(pedCoord, bluePrintCoord.seatCoords.x, bluePrintCoord.seatCoords.y, bluePrintCoord.seatCoords.z) <= bluePrintCoord.scale then
            Help(bluePrintCoord.seatCoords.help)
            if IsControlJustPressed(0, 38) then
                if currentObject == nil then
                    SpawnSeat()
                    InstallSeat()
                else
                    TriggerEvent('notification', objectError)
                end
            end
        end
        if Vdist(pedCoord, bluePrintCoord.breakCoord.x, bluePrintCoord.breakCoord.y, bluePrintCoord.breakCoord.z) <= bluePrintCoord.scale then
            Help(bluePrintCoord.breakCoord.help)
            if IsControlJustPressed(0, 38) then
                if currentObject == nil then
                    SpawnBrake()
                    InstallBreak()
                else
                    TriggerEvent('notification', objectError)
                end
            end
        end
        if Vdist(pedCoord, bluePrintCoord.wheelCoords.x, bluePrintCoord.wheelCoords.y, bluePrintCoord.wheelCoords.z) <= bluePrintCoord.scale then
            Help(bluePrintCoord.wheelCoords.help)
            if IsControlJustPressed(0, 38) then
                if currentObject == nil then
                    SpawnWheel()
                    InstallWheel()
                else
                    TriggerEvent('notification', objectError)
                end
            end
        end
        if Vdist(pedCoord, bluePrintCoord.trunkCoords.x, bluePrintCoord.trunkCoords.y, bluePrintCoord.trunkCoords.z) <= bluePrintCoord.scale then
            Help(bluePrintCoord.trunkCoords.help)
            if IsControlJustPressed(0, 38) then
                if currentObject == nil then
                    SpawnTrunk()
                    InstallTrunk()
                else
                    TriggerEvent('notification', objectError)
                end
            end
        end
        if Vdist(pedCoord, bluePrintCoord.bonnetCoords.x, bluePrintCoord.bonnetCoords.y, bluePrintCoord.bonnetCoords.z) <= bluePrintCoord.scale then
            Help(bluePrintCoord.bonnetCoords.help)
            if IsControlJustPressed(0, 38) then
                if currentObject == nil then
                    SpawnBonnet()
                    InstallBonnet()
                else
                    TriggerEvent('notification', objectError)
                end
            end
        end
        if Vdist(pedCoord, bluePrintCoord.engineCoords.x, bluePrintCoord.engineCoords.y, bluePrintCoord.engineCoords.z) <= bluePrintCoord.scale then
            Help(bluePrintCoord.engineCoords.help)
            if IsControlJustPressed(0, 38) then
                if currentObject == nil then
                    SpawnEngine()
                    InstallEngine()
                else
                    TriggerEvent('notification', objectError)
                end
            end
        end
        if Vdist(pedCoord, bluePrintCoord.transmissionCoords.x, bluePrintCoord.transmissionCoords.y, bluePrintCoord.transmissionCoords.z) <= bluePrintCoord.scale then
            Help(bluePrintCoord.transmissionCoords.help)
            if IsControlJustPressed(0, 38) then
                if currentObject == nil then
                    SpawnTransmission()
                    InstallTransmission()
                else
                    TriggerEvent('notification', objectError)
                end
            end
        end
        if Vdist(pedCoord, bluePrintCoord.exahustCoords.x, bluePrintCoord.exahustCoords.y, bluePrintCoord.exahustCoords.z) <= bluePrintCoord.scale then
            Help(bluePrintCoord.exahustCoords.help)
            if IsControlJustPressed(0, 38) then
                if currentObject == nil then
                    SpawnExhaust()
                    InstallExhaust()
                else
                    TriggerEvent('notification', objectError)
                end
            end
        end
        if Vdist(pedCoord, bluePrintCoord.analysisVehi.x, bluePrintCoord.analysisVehi.y, bluePrintCoord.analysisVehi.z) <= bluePrintCoord.scale then
            Help(bluePrintCoord.analysisVehi.help)
            if IsControlJustPressed(0, 38) then
                if currentObject == nil then
                    AnalysisVeh()
                else
                    TriggerEvent('notification', objectError)
                end
            end
        end
    end
end)

RegisterNetEvent('NumberPlateStr')
AddEventHandler('NumberPlateStr', function(plate) 
    numberPlate = plate
end)


Citizen.CreateThread(function()
    while true do
        Wait(10)
        DrawMarker(
            bluePrintCoord.bluePrintPos.id,--marker id
            bluePrintCoord.bluePrintPos.x, bluePrintCoord.bluePrintPos.y, bluePrintCoord.bluePrintPos.z - 1.0, --marker coordination
            0.0, 0.0, 0.0, --marker direction
            0.0, 0.0, 0.0, --marker rotation
            bluePrintCoord.scale, bluePrintCoord.scale, bluePrintCoord.scale, --marker scale
            bluePrintCoord.rbga.r, bluePrintCoord.rbga.g, bluePrintCoord.rbga.b, bluePrintCoord.rbga.a, --marker rgba color
            false, --up down animation
            false, --marker face to camera
            2,
            nil,
            nil,
            false
        )
        local pedCoord = GetEntityCoords(GetPlayerPed(-1))
        if Vdist(pedCoord, bluePrintCoord.bluePrintPos.x, bluePrintCoord.bluePrintPos.y, bluePrintCoord.bluePrintPos.z) <= bluePrintCoord.scale then
            Help(menuHelp)
            if IsControlJustPressed(0, 38) and not displayMenu then
                TriggerServerEvent('Manufacture:jobcheck')
            end
        end
    end
end)

RegisterCommand("export", function(source, args)
    if trailer == nil then
        RequestModel(GetHashKey('tr2'))
        while not HasModelLoaded(GetHashKey('tr2')) do
            Wait(0)
        end    
        local coords =  GetEntityCoords(GetPlayerPed(-1))
        trailer = CreateVehicle(GetHashKey('tr2'), trailerCoord.x, trailerCoord.y, trailerCoord.z, 0.0, true, false)
        SetVehicleDoorOpen(trailer, 5, false, false)
    end
    if trailer ~= nil then
        while true do
            Wait(0)
            if IsControlJustPressed(0, 38) then
                local veh = GetVehiclePedIsIn(PlayerPedId())
                local vehCoords = GetEntityCoords(veh)
                local vehRotation = GetEntityRotation(veh)
                AttachVehicleOnToTrailer(veh, trailer, 0.0, 0.0, 0.0, GetOffsetFromEntityGivenWorldCoords(trailer, vehCoords), vehRotation, false)
                break
            end
            if IsControlJustPressed(0, 73) then
                local veh = GetVehiclePedIsIn(PlayerPedId())
                DetachEntity(veh, true, false)
                break
            end
        end
    end
end)
RegisterCommand("trailerdoor", function(source, args)
    if trailer ~= nil then
        if GetVehicleDoorAngleRatio(trailer, 5) > 0.0 then
            SetVehicleDoorsShut(trailer, true)
        else
            SetVehicleDoorOpen(trailer, 5, false, false)
        end
    end
end)

RegisterCommand("true", function(source, args)
    berakState['0'] = true
berakState['1'] = true
berakState['2'] = true
berakState['3'] = true
berakState['4'] = true
berakState['5'] = true
seatState['-1'] = true
seatState['1'] = true
seatState['0'] = true
seatState['2'] = true
doorState['seat_dside_f'] = true
doorState['seat_dside_r'] = true
doorState['seat_pside_f'] = true
doorState['seat_pside_r'] = true
wheelState['0'] = true
wheelState['1'] = true
wheelState['2'] = true
wheelState['3'] = true
wheelState['4'] = true
wheelState['5'] = true
exhaust = true
engine = true
transmission = true
doorState['bonnet'] = true
doorState['trunk'] = true

UpdateShell()
end)

RegisterCommand('givemanfkeys', function(source, arg)
    local ped = GetPlayerPed(-1)
    if IsPedInAnyVehicle(ped, false) then
        local veh = GetVehiclePedIsIn(ped)
        local plate = GetVehicleNumberPlateText(veh)
        local vehicleProps = ESX.Game.GetVehicleProperties(veh)
        vehicleProps.plate = plate
        TriggerServerEvent('changeOwner', plate, arg[1], vehicleProps)
    else
        TriggerEvent('notification', 'Get in the vehicle to give keys')
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res == 'vehicle_man' then
        DeleteEntity(modelShell)
        DeleteObject(currentObject)
        ClearPedTasks(GetPlayerPed(-1))
    end
end)